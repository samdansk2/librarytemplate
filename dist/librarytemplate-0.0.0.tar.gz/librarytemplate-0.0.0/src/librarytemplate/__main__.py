"""Generic python package

Usage:
------



Contact:
--------

More information is available at:

- https://pypi.org/project/librarytemplate/
- https://github.com/samdansk2/librarytemplate


Version:
--------

- librarytemplate v0.0.1
"""
from librarytemplate.engine import engine

engine()
